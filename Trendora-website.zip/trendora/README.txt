TRENDORA WEBSITE
================
Open index.html to preview the website.

Included:
- Responsive modern storefront
- Home, Shop, Cart, About, Contact, FAQ
- Privacy Policy and Terms placeholders
- Product search + category filter
- Working browser cart using localStorage
- Starter product catalog

Before a real launch:
1. Replace sample products/prices with your inventory.
2. Add real product images.
3. Connect the contact form to email/WhatsApp/backend.
4. Connect a secure payment gateway and order database.
5. Replace Privacy/Terms placeholders with legally appropriate pages.
